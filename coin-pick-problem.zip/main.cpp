#include <iostream>
#include <bits/stdc++.h>
using namespace std;
// n->even no. of coins->8
// n inputs->1 2 3 4 5 6 100 7
// 2 players have to play optimally i.e. obtain the max sum himself and ensure other gets min sum
// coins can be picked from first or last positions only

// solns->there r 2 possiblilities i.e i can pick first coin or last coin
int coinsum(int a[], int i, int j)
{
    // base case
    if (i > j)
    {
        return 0;
    }
    // recursive case
    int firstpick = a[i] + min(coinsum(a, i + 2, j), coinsum(a, i, j - 1));
    int lastpick = a[j] + min(coinsum(a, i, j - 1), coinsum(a, i, j - 2));
    int ans = max(firstpick, lastpick);
    return ans;
}
int main()
{
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    cout << coinsum(a, 0, n - 1);
    return 0;
}












