#include<iostream>
using namespace std;
int noofdigits(int n){
    int c=0;
    while(n>0){
        c+=n%10;
        n/=10;
    }
    return c;
}
int main() {
    int n;
    cin>>n;
    int a=n;
    int sumf=0;
    for(int i=2;i<=n;i++){
        while(n%i==0){
            n/=i;
            sumf+=noofdigits(i);
        }
    }
    int s=0;
    while(a>0){
        int r=a%10;
        s=s+r;
        a=a/10;  
    }
      if(sumf==s){
          cout<<"1";
      }
      else{
          cout<<"0";
      }
    return 0;
}