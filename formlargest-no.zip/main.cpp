
#include<bits/stdc++.h>
using namespace std;
bool sortArray(string a,string b){
    return (a+b)<(b+a);
}
int main()
{
    int n;
    cin>>n;
    string array[n];
    for(int i=0;i<n;i++){
        cin>>array[i];
    }
    sort(array,array+n,sortArray);
    reverse(array,array+n);
    
    for(int i=0;i<n;i++){
        cout<<array[i];
    }
   
    return 0;
}